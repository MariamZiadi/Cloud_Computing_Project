from flask import Flask, jsonify, render_template, request
from flask_cors import CORS
import subprocess
import os
import re
import traceback
import json
app = Flask(__name__)
CORS(app)

# path to QEMU 
QEMU_PATH = "C:\\Program Files\\qemu"
QEMU_IMG = os.path.join(QEMU_PATH, "qemu-img.exe")
QEMU_SYSTEM = os.path.join(QEMU_PATH, "qemu-system-x86_64.exe")

DISK_DIR = "disks"
if not os.path.exists(DISK_DIR):
    os.makedirs(DISK_DIR)


def is_valid_disk_name(name):
    return re.match(r'^[\w\-.]+$', name)  

def is_valid_size(size):
    return re.match(r'^[1-9]\d*[MG]$', size.upper()) is not None
 

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/create_disk', methods=['POST'])
def create_disk():
    disk_name = request.form['disk_name']
    disk_size_value = request.form['disk_size_value']
    disk_size_unit = request.form['disk_size_unit']
    disk_size = f"{disk_size_value}{disk_size_unit}"
    disk_format = request.form.get('disk_format', 'qcow2') 
    disk_path = os.path.join('disks', disk_name)

    if not is_valid_disk_name(disk_name):
        return jsonify({'status': 'Error Invalid disk name'}), 400

    if not is_valid_size(disk_size):
        return jsonify({'status': 'Error Invalid disk size format'}), 400

    try:
        subprocess.run([QEMU_IMG, 'create', '-f', disk_format, disk_path, disk_size], check=True)
        return jsonify({'status': f"Disk {disk_name} created successfully with format {disk_format} and size {disk_size}"})
    except subprocess.CalledProcessError as e:
        return jsonify({'status': 'error', 'details': str(e)}), 500

@app.route('/disk_info', methods=['POST'])
def disk_info():
    disk_name = request.form['disk_name']
    disk_path = os.path.join(DISK_DIR, disk_name)

    cmd = [QEMU_IMG, 'info', disk_path]
    try:
        result = subprocess.run(cmd, capture_output=True, text=True)
        if result.returncode == 0:
            return jsonify({'status': 'ok', 'info': result.stdout})
        else:
            return jsonify({'status': 'error', 'details': result.stderr}), 400
    except Exception as e:
        return jsonify({'status': 'error', 'details': str(e)}), 500
#ahmed
@app.route('/convert_disk', methods=['POST'])
def convert_disk():
    source_disk = request.form['source_disk']
    output_format = request.form['output_format']
    output_name = request.form['output_name']

    source_path = os.path.join('disks', source_disk)
    output_path = os.path.join('disks', output_name)

    try:
        # Step 1: Detect actual format using qemu-img info
        info_result = subprocess.run(
            [QEMU_IMG, 'info', '--output', 'json', source_path],
            capture_output=True, text=True, check=True
        )
        info_json = json.loads(info_result.stdout)
        input_format = info_json.get('format')

        if not input_format:
            raise ValueError("Unable to detect disk format")

        # Step 2: Use detected format in conversion
        subprocess.run([QEMU_IMG, 'convert', '-f', input_format,
                        '-O', output_format, source_path, output_path], check=True)

        return jsonify({'status': f'Converted {source_disk} to {output_name} as {output_format} (from {input_format})'})

    except subprocess.CalledProcessError as e:
        traceback.print_exc()
        return jsonify({'error': f'Subprocess failed: {str(e)}'}), 500
    except Exception as e:
        traceback.print_exc()
        return jsonify({'error': f'Unexpected error: {str(e)}'}), 500

@app.route('/resize_disk', methods=['POST'])
def resize_disk():
    disk_name = request.form['disk_name']
    
    size_change_value = request.form['size_change_value']
    size_change_unit = request.form['size_change_unit']
    size_change = f"+{size_change_value}{size_change_unit}"
    disk_path = os.path.join(DISK_DIR, disk_name)

    cmd = [QEMU_IMG, 'resize', disk_path, size_change]
    try:    
        print(f"Running command: {' '.join(cmd)}")        
        result = subprocess.run(cmd, capture_output=True, text=True)        
        if result.returncode == 0:
            return jsonify({'status': 'Disk resized successfully'})
        else:
            return jsonify({'status': f'Error{result.stderr}'}), 400
    except Exception as e:    
        return jsonify({'status': 'Error', 'details': str(e)}), 500

@app.route('/delete_disk', methods=['POST'])
def delete_disk():
    disk_name = request.form['disk_name']
    disk_path = os.path.join(DISK_DIR, disk_name)
    try:
        os.remove(disk_path)
        return jsonify({'status': f'{disk_name} deleted successfully'})
    except Exception as e:
        return jsonify({'status': 'error', 'details': str(e)}), 500



@app.route('/list_disks', methods=['GET'])
def list_disks():
    try:
        files = os.listdir(DISK_DIR)
        disks = [f for f in files if os.path.isfile(os.path.join(DISK_DIR, f))]
        return jsonify({'disks': disks})
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/save_vm_config', methods=['POST'])
def save_vm_config():
    data = request.form
    vm_name = data.get('vm_name')
    if not vm_name:
        return jsonify({'status': 'error', 'details': 'VM name is required'}), 400
    
    os.makedirs('vm_configs', exist_ok=True)
    config_path = os.path.join('vm_configs', f"{vm_name}.json")
    if os.path.exists(config_path):
        return jsonify({'status': 'VM with this name already exists'}), 400

    config = {
        'disk_path': os.path.join(DISK_DIR, data['vm_disk']),
        'ram': f"{data['ram_size_value']}{data['ram_size_unit']}",
        'cpu': data['vm_cpu'],
        'boot': data.get('vm_boot', 'c'),
        'boot_path': data.get('iso_file', '').strip()
    }

    
    with open(config_path, 'w') as f:
        json.dump(config, f)

    return jsonify({'status': f'Config for {vm_name} saved successfully'})

@app.route('/list_vms', methods=['GET'])
def list_vms():
    vm_dir = 'vm_configs'
    try:
        vms = []
        for fname in os.listdir(vm_dir):
            if fname.endswith('.json'):
                with open(os.path.join(vm_dir, fname)) as f:
                    config = json.load(f)
                    config['name'] = fname.rsplit('.', 1)[0]
                    vms.append(config)
        return jsonify(vms)
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/run_vm', methods=['POST'])
def run_vm():
    data = request.get_json()
    vm_name = data.get('vm_name')
    if not vm_name:
        return jsonify({'status': 'error', 'details': 'VM name is required'}), 400

    config_path = os.path.join('vm_configs', f"{vm_name}.json")
    if not os.path.exists(config_path):
        return jsonify({'status': 'error', 'details': f'Config for {vm_name} not found'}), 404

    with open(config_path) as f:
        config = json.load(f)

    disk_path = config['disk_path']
    ram = config['ram']
    cpu = config['cpu']
    boot = config.get('boot', 'c')
    boot_path = config.get('boot_path', '').strip()

    if not os.path.exists(disk_path):
        return jsonify({'status': f'error Disk file {disk_path} does not exist'}), 400

    cmd = [
        QEMU_SYSTEM,
        '-hda', disk_path,
        '-m', ram,
        '-smp', cpu,
        '-boot', f'order={boot}',
        '-display', 'sdl'
    ]

    if boot == 'd' and boot_path:
        if os.path.exists(boot_path):
            cmd += ['-cdrom', boot_path]
        else:
            return jsonify({'status': 'error', 'details': f'CD-ROM file not found: {boot_path}'}), 400
    elif boot in ['a', 'b'] and boot_path:
        if os.path.exists(boot_path):
            cmd += ['-fda' if boot == 'a' else '-fdb', boot_path]
        else:
            return jsonify({'status': 'error', 'details': f'Floppy file not found: {boot_path}'}), 400

    try:
        subprocess.Popen(cmd)
        return jsonify({'status': 'VM started!'}), 200
    except Exception as e:
        return jsonify({'status': f'error {str(e)}'}), 500

@app.route('/delete_vm', methods=['POST'])
def delete_vm():
    data = request.get_json()
    vm_name = data.get('vm_name')   
    print(vm_name)

    if not vm_name:
        return jsonify({'status': 'error', 'details': 'VM name is required'}), 400


    config_path = os.path.join('vm_configs', f"{vm_name}.json")

    if not os.path.exists(config_path):
        return jsonify({'status': 'error', 'details': f'Config {vm_name}.json not found'}), 404

    try:
        os.remove(config_path)
        return jsonify({'status': f'{vm_name} deleted successfully'})
    except Exception as e:
        return jsonify({'status': f'error: {str(e)}'}), 500

@app.route('/edit_vm_config', methods=['POST'])
def edit_vm_config():
    vm_name = request.form.get('vm_name')
    if not vm_name:
        return jsonify({'status': 'error', 'details': 'VM name is required'}), 400

    config_path = os.path.join('vm_configs', f"{vm_name}.json")
    if not os.path.exists(config_path):
        return jsonify({'status': 'error', 'details': 'VM not found'}), 404

    iso_file = request.form.get('iso_file', '').strip()  
    if not iso_file:
        iso_file = request.form.get('current_iso_path', '').strip() 

    config = {
        'disk_path': os.path.join(DISK_DIR, request.form['vm_disk']),
        'ram': f"{request.form['ram_size_value']}{request.form['ram_size_unit']}",
        'cpu': request.form['vm_cpu'],
        'boot': request.form.get('vm_boot', 'c'),
        'boot_path': iso_file, 
        'name': vm_name
    }

    with open(config_path, 'w') as f:
        json.dump(config, f)

    return jsonify({'status': f'Config for {vm_name} updated successfully'})





if __name__ == '__main__':
    app.run(debug=True)


