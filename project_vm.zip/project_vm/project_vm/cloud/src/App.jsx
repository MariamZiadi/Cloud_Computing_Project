import CreateDiskForm from './componentes/CreateDiskForm';
import DiskInfoForm from './componentes/DiskInfoForm';
import ConvertDiskForm from './componentes/ConvertDiskForm';
import ResizeDiskForm from './componentes/ResizeDiskForm';
import DeleteDiskForm from './componentes/DeleteDiskForm';
import CreateVMForm from './componentes/CreateVMForm';
import { useState } from 'react';
import Sidebar from './componentes/sidebar';
import { Plus, Info, Repeat, MoveDiagonal, Trash2, Monitor } from 'lucide-react';
import AvailableVMs from './componentes/ViewVms';
const tabs = {
  disk: [
    { key: 'create_disk', label: 'Create Disk', icon: <Plus size={16} />, component: <CreateDiskForm /> },
    { key: 'view_disk', label: 'View Disk Info', icon: <Info size={16} />, component: <DiskInfoForm /> },
    { key: 'convert_disk', label: 'Convert Disk', icon: <Repeat size={16} />, component: <ConvertDiskForm /> },
    { key: 'resize_disk', label: 'Resize Disk', icon: <MoveDiagonal size={16} />, component: <ResizeDiskForm /> },
    { key: 'delete_disk', label: 'Delete Disk', icon: <Trash2 size={16} />, component: <DeleteDiskForm /> },
  ],
  vm: [
    { key: 'create_vm', label: 'Create VM', icon: <Monitor size={16} />, component: <CreateVMForm /> },
    { key: 'view_vms', label: 'Available VMs', icon: <Monitor size={16} />, component: <AvailableVMs /> },
  ],
};



export default function App() {
  const [activeTab, setActiveTab] = useState('create_disk');

  const currentComponent =
    Object.values(tabs).flat().find((tab) => tab.key === activeTab)?.component || null;

  return (
    <div className="flex min-h-screen bg-gray-100">
      <Sidebar tabs={tabs} activeTab={activeTab} setActiveTab={setActiveTab} />
      <main className="flex-1 p-6">
        {currentComponent}
      </main>
    </div>
  );
}