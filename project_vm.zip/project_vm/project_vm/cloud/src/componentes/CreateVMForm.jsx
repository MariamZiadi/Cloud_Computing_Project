import { useState } from 'react';
import { useDiskList, useRefreshDisks } from './useDiskList';

export default function CreateVMForm() {
  const [saveResponse, setsaveResponse] = useState('');
  const disks = useDiskList();
  const refreshDisks = useRefreshDisks();
  const [isoFileName, setIsoFileName] = useState('');
  const handleSubmit = async (e) => {
    e.preventDefault();
    const form = new FormData(e.target);
    if (isoFileName) {
      form.set('iso_file', isoFileName);
    }
    const save = await fetch('http://localhost:5000/save_vm_config', {
      method: 'POST',
      body: form,
    });
    const savejson = await save.json();
    setsaveResponse(savejson.status || savejson.error || savejson.stringify(json));
    refreshDisks();
  };

  const handleFileChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      setIsoFileName(file.name);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4 p-6 rounded-2xl border shadow bg-white">
      <h2 className="text-xl font-bold">Create VM</h2>

      <div>
          <label className="block font-medium mb-1">Name:</label>
          <div className="flex gap-2">
            <input
              name="vm_name"
              placeholder="VM Name"
              className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
              required
            />
          </div>
        </div>

      <label className="block">
        <span className="block text-sm font-medium">Disk:</span>
        <select name="vm_disk" className="mt-1 block w-full rounded-xl border p-2" required>
          <option value="">-- Choose a disk --</option>
          {Array.isArray(disks) && disks.map((d) => (
            <option key={d} value={d}>{d}</option>
          ))}
        </select>
      </label>

      <div>
          <label className="block font-medium mb-1">Ram:</label>
          <div className="flex gap-2">
            <input
              name="ram_size_value"
              type="number"
              min = "1"
              placeholder="Size"
              className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
              required
            />
            <select name="ram_size_unit" className="w-1/3 border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500">
              <option value="M">MB</option>
              <option value="G">GB</option>
            </select>
          </div>
        </div>

      <label className="block">
        <span className="block text-sm font-medium">CPU Cores:</span>
        <input name="vm_cpu" type="number" min='1' placeholder="e.g., 2" className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500" required />
      </label>

      <label className="block">
        <span className="block text-sm font-medium">Boot Device (c, d, a, b):</span>
        <select name="vm_boot" defaultValue="c" className="mt-1 block w-full rounded-xl border p-2">
          <option value="c">Hard Disk (c)</option>
          <option value="d">CD-ROM (d)</option>
          <option value="a">Floppy A</option>
          <option value="b">Floppy B</option>
        </select>
      </label>

      <label className="block">
        <span className="block text-sm font-medium">ISO File (OS image):</span>
        <input
          type="file"
          name="iso_file"
          accept=".iso"
          className="mt-1 block w-full text-sm text-gray-700
               file:mr-4 file:py-2 file:px-4
               file:rounded file:border-0
               file:text-xs 
               file:bg-blue-600 file:text-white
               hover:file:bg-blue-700"
          onChange={handleFileChange}
        />
      </label>

      <div className="flex justify-center">
        <button type="submit" className="bg-blue-600 text-white px-4 py-2 w-full rounded hover:bg-green-700">
          create VM
        </button>
      </div>

      <pre className="bg-gray-100 p-2 mt-2 rounded whitespace-pre-wrap">{saveResponse} </pre>
    </form>
  );
}
