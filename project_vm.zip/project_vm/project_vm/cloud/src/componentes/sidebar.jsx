export default function Sidebar({ tabs, activeTab, setActiveTab }) {
    return (
        <aside className="w-64 bg-white shadow h-screen p-4 space-y-6">
            <div>
                <h2 className="text-lg font-semibold mb-2">Disk Mangment</h2>
                {tabs.disk.map(tab => (
                    <button
                        key={tab.key}
                        onClick={() => setActiveTab(tab.key)}
                        className={`flex items-center gap-2 w-full text-left px-4 py-2 rounded-xl ${activeTab === tab.key ? 'bg-blue-200 font-bold' : 'hover:bg-gray-100'
                            }`}
                    >
                        {tab.icon}
                        {tab.label}
                    </button>
                ))}
            </div>
            <div>
                <h2 className="text-lg font-semibold mb-2">VM Mangment</h2>
                {tabs.vm.map(tab => (
                    <button
                        key={tab.key}
                        onClick={() => setActiveTab(tab.key)}
                        className={`flex items-center gap-2 w-full text-left px-4 py-2 rounded-xl ${activeTab === tab.key ? 'bg-blue-200 font-bold' : 'hover:bg-gray-100'
                            }`}
                    >
                        {tab.icon}
                        {tab.label}
                    </button>
                ))}
            </div>
        </aside>
    );
}
