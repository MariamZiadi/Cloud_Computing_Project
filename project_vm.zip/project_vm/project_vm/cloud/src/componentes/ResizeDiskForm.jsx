import { useState } from 'react';
import { useDiskList, useRefreshDisks } from './useDiskList';

export default function ResizeDiskForm() {
  const [response, setResponse] = useState('');
  const disks = useDiskList();
  const refreshDisks = useRefreshDisks();
  const handleSubmit = async (e) => {
    e.preventDefault();
    const form = new FormData(e.target);
    const res = await fetch('http://localhost:5000/resize_disk', {
      method: 'POST',
      body: form,
    });
    const json = await res.json();
    setResponse(json.status || json.error || JSON.stringify(json));
    refreshDisks();
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4 border p-6 rounded-2xl shadow bg-white">
      <h2 className="text-xl font-bold">Resize Disk</h2>
      <label className="block">
        <span className="block text-sm font-medium">Disk:</span>
        <select name="disk_name" className="mt-1 block w-full rounded-xl border p-2" required>
          <option value="">-- Choose a disk --</option>
          {Array.isArray(disks) && disks.map((d) => (
            <option key={d} value={d}>{d}</option>
          ))}
        </select>
      </label>

      <div>
        <label className="block font-medium mb-1">Size:</label>
        <div className="flex gap-2">
          <input
            name="size_change_value"
            type="number"
            min="1"
            placeholder="Size"
            className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
            required
          />
          <select name="size_change_unit" className="w-1/3 border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500">
            <option value="M">MB</option>
            <option value="G">GB</option>
          </select>
        </div>
      </div>

      <button type="submit" className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700">Resize</button>
      <pre className="bg-gray-100 p-2 mt-2 rounded whitespace-pre-wrap">{response}</pre>
    </form>
  );
}
