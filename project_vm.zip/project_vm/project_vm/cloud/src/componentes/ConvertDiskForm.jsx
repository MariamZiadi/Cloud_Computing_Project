import { useState } from 'react';
import { useDiskList, useRefreshDisks } from './useDiskList';

export default function ConvertDiskForm() {
  const [response, setResponse] = useState('');
  const disks  = useDiskList();
  const refreshDisks = useRefreshDisks();
  const handleSubmit = async (e) => {
    e.preventDefault();
    const form = new FormData(e.target);
    form.set("disk_format", form.get("output_format"));
    const res = await fetch('http://localhost:5000/convert_disk', {
      method: 'POST',
      body: form,
    });
    const json = await res.json();
    setResponse(json.status || json.error || JSON.stringify(json));
    refreshDisks();
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4 p-6 rounded-2xl border shadow bg-white">
      <h2 className="text-xl font-bold">Convert Disk</h2>
      <label className="block">
        <span className="block text-sm font-medium">Source Disk:</span>
        <select name="source_disk" className="mt-1 block w-full rounded-xl border p-2" required>
          <option value="">-- Choose a disk --</option>
          {Array.isArray(disks) && disks.map((d) => (
            <option key={d} value={d}>{d}</option>
          ))}
        </select>
      </label>
      <label className="block">
        <span className="block text-sm font-medium">Output Format:</span>
        <select name="output_format" className="mt-1 block w-full rounded-xl border p-2" required>
          <option value="qcow2">qcow2</option>
          <option value="raw">raw</option>
          <option value="vmdk">vmdk</option>
        </select>
      </label>
      <label className="block">
        <span className="block text-sm font-medium">Output Name:</span>
        <input name="output_name" placeholder="e.g., newdisk.qcow2" className="mt-1 block w-full border p-2 rounded-xl" required />
      </label>
      <button type="submit" className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700">Convert</button>
      <pre className="bg-gray-100 p-2 mt-2 rounded whitespace-pre-wrap">{response}</pre>
    </form>
  );
}
