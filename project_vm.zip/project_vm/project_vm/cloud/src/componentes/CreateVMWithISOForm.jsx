import { useState } from 'react';

export default function CreateVMWithISOForm() {
  const [result, setResult] = useState('');

  const handleSubmit = async (e) => {
    e.preventDefault();
    const form = new FormData(e.target);

    const res = await fetch('/create_vm_iso', {
      method: 'POST',
      body: form
    });

    const json = await res.json();
    setResult(json.status || json.details || JSON.stringify(json));
  };

  return (
    <form onSubmit={handleSubmit}>
      <h2>Create VM with ISO</h2>
      <input name="vm_disk" placeholder="Disk name" required />
      <input name="iso_path" placeholder="Path to ISO" required />
      <input name="vm_ram" placeholder="RAM (e.g. 1024)" required />
      <input name="vm_cpu" placeholder="CPUs (e.g. 2)" required />
      <button type="submit">Start VM with ISO</button>
      <p>{result}</p>
    </form>
  );
}
