import { useEffect, useState } from 'react';
import { Play, HardDrive, Trash, Pen } from 'lucide-react';
import { useDiskList } from './useDiskList';
export default function AvailableVMs() {
    const [vms, setVMs] = useState([]);
    const [error, setError] = useState('');
    const [editVM, setEditVM] = useState(null);
    const disks = useDiskList();
    const [isoFileName, setIsoFileName] = useState('');

    const handleFileChange = (e) => {
        const file = e.target.files[0];
        if (file) {
            setIsoFileName(file.name);
        }
    }
    const fetchVMs = async () => {
        try {
            const res = await fetch('http://localhost:5000/list_vms');
            const data = await res.json();
            if (res.ok) setVMs(data);
            else setError(data.error || 'Failed to load VMs');
        } catch (err) {
            setError(err.message);
        }
    };
    useEffect(() => {

        fetchVMs();
    }, []);

    const runVM = async (vmName) => {
        try {
            const response = await fetch('http://localhost:5000/run_vm', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ vm_name: vmName })
            });

            const result = await response.json();
        } catch (error) {
            console.error('Error running VM:', error);
            alert('Failed to run VM');
        }
    };

    const deleteVM = async (vmName) => {
        try {
            const response = await fetch('http://localhost:5000/delete_vm', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ vm_name: vmName.name })
            });
            const result = await response.json();
            setVMs(vms.filter(name => name !== vmName));
        } catch (error) {
            console.error('Error deleting VM:', error);
            alert('Failed to delete VM');
        }
    };


    return (
        <div className="space-y-4">
            <h2 className="text-2xl font-bold">Available VMs</h2>

            {vms.length === 0 ? (
                <p className="text-gray-500">No saved VMs found.</p>
            ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                    {vms.map((vm) => (
                        <div key={vm.name} className="bg-white shadow rounded-xl p-4 flex flex-col justify-between">
                            <div>
                                <div className="flex items-center gap-2 mb-2 text-lg font-semibold">
                                    <HardDrive size={18} />
                                    {vm.name}
                                </div>
                                <ul className="text-sm text-gray-700 space-y-1">
                                    <li><strong>RAM:</strong> {vm.ram}</li>
                                    <li><strong>CPU cores:</strong> {vm.cpu}</li>
                                    <li><strong>Disk:</strong> {vm.disk_path}</li>
                                    <li><strong>Boot:</strong> {vm.boot} {vm.boot_path && `(${vm.boot_path})`}</li>
                                </ul>
                            </div>
                            <div className='flex'>
                                <button
                                    onClick={() => runVM(vm.name)}
                                    className="mt-4 bg-green-600 hover:bg-green-700 text-white font-medium py-1.5 px-3 rounded-lg flex items-center justify-center gap-1 mr-2"
                                >
                                    <Play size={16} /> Run VM
                                </button>
                                <button
                                    onClick={() => setEditVM(vm)}
                                    className="mt-4 bg-blue-600 hover:bg-blue-700 text-white font-medium py-1.5 px-3 rounded-lg flex items-center justify-center gap-1 mr-2"
                                >
                                    <Pen size={16} /> edit
                                </button>
                                <button
                                    onClick={() => deleteVM(vm)}
                                    className="mt-4 bg-red-600 hover:bg-red-700 text-white font-medium py-1.5 px-3 rounded-lg flex items-center justify-center gap-1"
                                >
                                    <Trash size={16} />Delete
                                </button>
                            </div>
                        </div>
                    ))}
                </div>
            )}
            {editVM && (
                <form
                    className="bg-white p-6 rounded-2xl shadow mt-4 space-y-4"
                    onSubmit={async (e) => {
                        e.preventDefault();
                        const formData = new FormData(e.target);
                        if (isoFileName) {
                            formData.set('iso_file', isoFileName);
                        }
                        try {
                            const res = await fetch('http://localhost:5000/edit_vm_config', {
                                method: 'POST',
                                body: formData,
                            });
                            const data = await res.json();
                            console.log(data);
                            setEditVM(null);
                            fetchVMs(); // Refresh the list
                        } catch (error) {
                            console.error('Error editing VM:', error);
                            alert('Failed to edit VM.');
                        }
                    }}
                >
                    <h2 className="text-xl font-bold">Edit VM</h2>

                    <div>
                        <label className="block font-medium mb-1">Name:</label>
                        <input
                            name="vm_name"
                            defaultValue={editVM.name}
                            className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                            required
                        />
                    </div>

                    <label className="block">
                        <span className="block text-sm font-medium">Disk:</span>
                        <select name="vm_disk" className="mt-1 block w-full rounded-xl border p-2" required>
                            <option value="">-- Choose a disk --</option>
                            {Array.isArray(disks) &&
                                disks.map((d) => (
                                    <option key={d} value={d} selected={d === editVM.disk_path.split('\\').pop()}>
                                        {d}
                                    </option>
                                ))}
                        </select>
                    </label>

                    <div>
                        <label className="block font-medium mb-1">Ram:</label>
                        <div className="flex gap-2">
                            <input
                                name="ram_size_value"
                                type="number"
                                min="1"
                                defaultValue={parseInt(editVM.ram)}
                                placeholder="Size"
                                className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                                required
                            />
                            <select
                                name="ram_size_unit"
                                defaultValue={editVM.ram.replace(/\d+/g, '')}
                                className="w-1/3 border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                            >
                                <option value="M">MB</option>
                                <option value="G">GB</option>
                            </select>
                        </div>
                    </div>

                    <label className="block">
                        <span className="block text-sm font-medium">CPU Cores:</span>
                        <input
                            name="vm_cpu"
                            type="number"
                            min="1"
                            defaultValue={editVM.cpu}
                            className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                            required
                        />
                    </label>

                    <label className="block">
                        <span className="block text-sm font-medium">Boot Device (c, d, a, b):</span>
                        <select name="vm_boot" defaultValue={editVM.boot} className="mt-1 block w-full rounded-xl border p-2">
                            <option value="c">Hard Disk (c)</option>
                            <option value="d">CD-ROM (d)</option>
                            <option value="a">Floppy A</option>
                            <option value="b">Floppy B</option>
                        </select>
                    </label>
                    <input type="hidden" name="current_iso_path" value={editVM.boot_path} />
                    <label className="block">
                        <span className="block text-sm font-medium">
                            ISO File (OS image){' '}
                            {editVM?.boot_path && (
                                <>
                                    Leave empty to keep current ISO: <strong>{editVM.boot_path.split('\\').pop()}</strong>
                                </>
                            )}
                            :
                        </span>
                        <input
                            type="file"
                            name="iso_file"
                            accept=".iso"
                            className="mt-1 block w-full text-sm text-gray-700
         file:mr-4 file:py-2 file:px-4
         file:rounded file:border-0
         file:text-xs 
         file:bg-blue-600 file:text-white
         hover:file:bg-blue-700"
                            onChange={handleFileChange}
                        />

                    </label>


                    <div className="flex justify-end gap-2 pt-2">
                        <button type="submit" className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-green-700">
                            Save Changes
                        </button>
                        <button
                            type="button"
                            onClick={() => setEditVM(null)}
                            className="bg-gray-300 px-4 py-2 rounded"
                        >
                            Cancel
                        </button>
                    </div>
                </form>
            )}


        </div>
    );
}