import { useState } from 'react';
import { useDiskList, useRefreshDisks } from './useDiskList';

export default function DeleteDiskForm() {
  const [response, setResponse] = useState('');
  const  disks  = useDiskList();
  const refreshDisks = useRefreshDisks();
  const handleSubmit = async (e) => {
    e.preventDefault();
    const form = new FormData(e.target);
    const res = await fetch('http://localhost:5000/delete_disk', {
      method: 'POST',
      body: form,
    });
    const json = await res.json();
    setResponse(json.status || json.error || JSON.stringify(json));
    refreshDisks();
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4 p-6 rounded-2xl border shadow bg-white">
      <h2 className="text-xl font-bold">Delete Disk</h2>
      <label className="block">
        <span className="block text-sm font-medium">Select Disk:</span>
        <select name="disk_name" className="mt-1 block w-full rounded-xl border p-2" required>
          <option value="">-- Choose a disk --</option>
          {Array.isArray(disks) && disks.map((d) => (
            <option key={d} value={d}>{d}</option>
          ))}
        </select>
      </label>
      <button type="submit" className="bg-red-600 text-white px-4 py-2 rounded hover:bg-red-700">Delete</button>
      <pre className="bg-gray-100 p-2 mt-2 rounded whitespace-pre-wrap">{response}</pre>
    </form>
  );
}
