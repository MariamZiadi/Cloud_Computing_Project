import { useContext } from 'react';
import { DiskContext } from './DiskContext';

export const useDiskList = () => {
  const context = useContext(DiskContext);
  return context?.disks || []; 
};

export const useRefreshDisks = () => {
  const context = useContext(DiskContext);
  return context?.refresh || (() => {});
};
