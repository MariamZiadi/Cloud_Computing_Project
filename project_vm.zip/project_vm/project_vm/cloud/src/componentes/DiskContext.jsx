// DiskContext.jsx
import { createContext, useState, useEffect, useCallback } from 'react';

export const DiskContext = createContext();

export const DiskProvider = ({ children }) => {
  const [disks, setDisks] = useState([]);
  const [refreshIndex, setRefreshIndex] = useState(0);

  const fetchDisks = useCallback(async () => {
    try {
      const res = await fetch('http://localhost:5000/list_disks');
      const json = await res.json();
      console.log("Fetched disks:", json); 
      if (Array.isArray(json.disks)) {
        setDisks(json.disks);
      }
    } catch (err) {
      console.error('Error fetching disks:', err);
    }
  }, []);

  useEffect(() => {
    fetchDisks();
  }, [fetchDisks, refreshIndex]);

  const refresh = () => setRefreshIndex((i) => i + 1);

  return (
    <DiskContext.Provider value={{ disks, refresh }}>
      {children}
    </DiskContext.Provider>
  );
};
