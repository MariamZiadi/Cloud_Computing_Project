import { useState } from 'react';
import { useDiskList, useRefreshDisks } from './useDiskList';

export default function DiskInfoForm() {
  const [response, setResponse] = useState('');
  const disks  = useDiskList();
  const refreshDisks = useRefreshDisks();
  const handleSubmit = async (e) => {
    e.preventDefault();
    const form = new FormData(e.target);
    const res = await fetch('http://localhost:5000/disk_info', {
      method: 'POST',
      body: form,
    });
    const json = await res.json();
    setResponse(json.info || json.error || JSON.stringify(json));
    refreshDisks();
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4 p-6 rounded-2xl border shadow bg-white">
      <h2 className="text-xl font-bold">View Disk Info</h2>
      <label className="block">
        <span className="block text-sm font-medium">Select Disk:</span>
        <select name="disk_name" className="mt-1 block w-full rounded-xl border p-2" required>
          <option value="">-- Choose a disk --</option>
          {Array.isArray(disks) && disks.length > 0 ? (
            disks.map((d) => (
              <option key={d} value={d}>{d}</option>
            ))
          ) : (
            <option disabled>No disks available</option>
          )}F
        </select>
      </label>
      <button type="submit" className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700">
        Get Info
      </button>
      <pre className="bg-gray-100 p-2 mt-2 rounded whitespace-pre-wrap">{response}</pre>
    </form>
  );
}

