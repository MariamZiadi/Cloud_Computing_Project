import { useState } from 'react';
import { useRefreshDisks } from './useDiskList';

export default function CreateDiskForm() {
  const [response, setResponse] = useState('');
  const refreshDisks = useRefreshDisks();
  const handleSubmit = async (e) => {
    e.preventDefault();
    const form = new FormData(e.target);

    const res = await fetch('http://localhost:5000/create_disk', {
      method: 'POST',
      body: form,
    });

    const json = await res.json();
    setResponse(json.status || json.error || JSON.stringify(json));
    refreshDisks();
  };

  return (
    <div className="bg-white p-6 rounded-2xl shadow-md">
      <h2 className="text-2xl font-bold mb-4">Create Disk</h2>
      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label className="block font-medium mb-1">Name:</label>
          <input
            name="disk_name"
            placeholder="e.g., disk.qcow2"
            required
            className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
        </div>
        <div>
          <label className="block font-medium mb-1">Size:</label>
          <div className="flex gap-2">
            <input
              name="disk_size_value"
              type="number"
              min="1"
              placeholder="Size"
              className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
              required
            />
            <select name="disk_size_unit" className="w-1/3 border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500">
              <option value="M">MB</option>
              <option value="G">GB</option>
            </select>
          </div>
        </div>

        <div>
          <label className="block font-medium mb-1">Format:</label>
          <select
            name="disk_format"
            defaultValue="qcow2"
            className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
          >
            <option value="qcow2">qcow2</option>
            <option value="raw">raw</option>
            <option value="vmdk">vmdk</option>
          </select>
        </div>

        <button
          type="submit"
          className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700 transition"
        >
          Create
        </button>

        <p className="text-sm text-gray-700 whitespace-pre-line">{response}</p>
      </form>
    </div>
  );
}
