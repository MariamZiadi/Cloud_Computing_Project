import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

// https://vite.dev/config/
export default defineConfig({
  plugins: [react()],
  server: {
    proxy: {
      '/create_disk': 'http://localhost:5000',
      '/disk_info': 'http://localhost:5000',
      '/convert_disk': 'http://localhost:5000',
      '/resize_disk': 'http://localhost:5000',
      '/delete_disk': 'http://localhost:5000',
      '/create_vm': 'http://localhost:5000',
      '/create_vm_iso': 'http://localhost:5000',
    }
  }
})
